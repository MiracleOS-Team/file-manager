# Privacy Policy

The privacy policy has been moved to here https://files.community/privacy