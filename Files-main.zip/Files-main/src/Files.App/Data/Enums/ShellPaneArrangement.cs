﻿// Copyright (c) Files Community
// Licensed under the MIT License.

namespace Files.App.Data.Enums
{
	public enum ShellPaneArrangement
	{
		None,

		Horizontal,

		Vertical,
	}
}
