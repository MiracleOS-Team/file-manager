﻿// Copyright (c) Files Community
// Licensed under the MIT License.

namespace Files.App.Data.Enums
{
	public enum FilesystemOperationType
	{
		/// <summary>
		/// Copy storage object.
		/// </summary>
		Copy = 0,

		/// <summary>
		/// Move storage object.
		/// </summary>
		Move = 1,

		/// <summary>
		/// Delete storage object.
		/// </summary>
		Delete = 2
	}
}
