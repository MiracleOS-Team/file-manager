﻿// Copyright (c) Files Community
// Licensed under the MIT License.

namespace Files.App.Controls
{
	/// <summary>
	/// Interface to scope allowed items in the Private Item list
	/// </summary>
	public interface IToolbarItemSet
	{
	}
}
